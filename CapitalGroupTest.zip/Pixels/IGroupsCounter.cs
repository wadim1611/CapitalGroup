﻿namespace Pixels
{
    public interface IGroupsCounter
    {
        int CountGroups(char[][] monitor);
    }
}
